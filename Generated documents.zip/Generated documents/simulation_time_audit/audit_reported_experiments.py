from pathlib import Path
import json,csv,math,hashlib
root=Path.cwd();reg=json.loads((root/'Evaluation/training_run_locations.json').read_text())
a=[Path(r['new']) for r in reg['entries'] if r['environment']=='A' and r['completed_episodes']==1600];b=[]
for base in [root/'baseline/results',*[p for p in root.glob('Ablation *') if p.is_dir()]]:b.extend(p.parent for p in (base/'training/environment_B').glob('seed_*/*/episodes.csv'))
cm=Path((root/'Evaluation/comparisons/environment_C_rev2/common_outcomes/CURRENT_DATA.txt').read_text().strip());sources=json.loads((cm/'manifest.json').read_text())['sources'];c=[Path(s['directory']) for s in sources];records=[];totals={}
assert len(a)==len(b)==len(c)==18
for group,dirs in [('A',a),('B',b),('C',c)]:
 start=len(records)
 for d in dirs:
  with (d/'episodes.csv').open() as f:rows=list(csv.DictReader(f))
  expected=160 if group=='C' else 1600
  assert len(rows)==expected,(d,len(rows));assert [int(r['episode']) for r in rows]==list(range(1,expected+1))
  vals=[float(r['duration_sim_s']) for r in rows];wall=[float(r['duration_wall_s']) for r in rows];assert all(math.isfinite(v) and v>=0 for v in vals+wall)
  metadata=json.loads((d/'metadata.json').read_text());assert metadata['training_stage']==(2 if group in ('B','C') else 1) and metadata['mode']==('eval' if group=='C' else 'train')
  records.append(dict(environment=group,run_id=metadata['run_id'],directory=str(d),episodes=len(rows),duration_sim_s=sum(vals),duration_wall_s=sum(wall),episodes_sha256=hashlib.sha256((d/'episodes.csv').read_bytes()).hexdigest()))
 part=records[start:];totals[group]=dict(runs=len(part),episodes=sum(r['episodes'] for r in part),sim_hours=sum(r['duration_sim_s'] for r in part)/3600,active_mission_wall_hours=sum(r['duration_wall_s'] for r in part)/3600)
assert len({r['run_id'] for r in records})==54
p=root/'Generated documents/simulation_time_audit';p.mkdir(exist_ok=True)
with (p/'reported_experiments_run_durations.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(records[0]));w.writeheader();w.writerows(records)
totals['total']=dict(runs=len(records),episodes=sum(r['episodes'] for r in records),sim_hours=sum(r['duration_sim_s'] for r in records)/3600,active_mission_wall_hours=sum(r['duration_wall_s'] for r in records)/3600)
(p/'reported_experiments_totals.json').write_text(json.dumps(dict(scope='Final reported A/B training and C revision2 zero-shot evaluation; excludes pilots, discarded runs, diagnostic tests, resets and simulator idle/setup time.',definition='Sum of completed-episode duration_sim_s; duration_wall_s is active episode wall time, not whole-project elapsed time.',totals=totals),indent=2)+'\n');(p/'audit_reported_experiments.py').write_bytes(Path(__file__).read_bytes());print(json.dumps(totals,indent=2))
